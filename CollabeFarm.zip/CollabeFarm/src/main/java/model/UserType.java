package model;

public enum UserType {
    admin,
    farmer,
    company,
    service_provider,
    landowner
}
